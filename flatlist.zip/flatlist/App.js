import React,{useState} from 'react';
import { Text, View, StyleSheet,FlatList } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {

  const [people,setPeople]=useState([
    {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
    {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
    {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
       {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
    {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
    {name:'serhat',key:1},{name:'serpil',key:2},
    {name:"murat",key:3},{name:'selim',key:4},
  ]);
  return (
    <View style={styles.container}>
     <FlatList
     //numColumns={2}
 data={people}
 renderItem={({item})=>(
   <Text style={styles.name}>name is {item.name}</Text>
 )}
     />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  name:{

    fontSize:25,
    margin:5,backgroundColor:'orange',
    padding:10,
  borderRadius:40
    
  }
});
